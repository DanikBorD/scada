﻿namespace ScadaTableEditor
{
    partial class FrmItemInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInCnl = new System.Windows.Forms.Label();
            this.txtInCnlNum = new System.Windows.Forms.TextBox();
            this.txtInCnlName = new System.Windows.Forms.TextBox();
            this.txtCtrlCnlName = new System.Windows.Forms.TextBox();
            this.txtCtrlCnlNum = new System.Windows.Forms.TextBox();
            this.lblCtrlCnl = new System.Windows.Forms.Label();
            this.txtInCnlObjName = new System.Windows.Forms.TextBox();
            this.txtInCnlObjNum = new System.Windows.Forms.TextBox();
            this.lblInCnlObj = new System.Windows.Forms.Label();
            this.txtInCnlKPName = new System.Windows.Forms.TextBox();
            this.txtInCnlKPNum = new System.Windows.Forms.TextBox();
            this.lblInCnlKP = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.gbInCnl = new System.Windows.Forms.GroupBox();
            this.gbCtrlCnl = new System.Windows.Forms.GroupBox();
            this.txtCtrlCnlKPName = new System.Windows.Forms.TextBox();
            this.txtCtrlCnlKPNum = new System.Windows.Forms.TextBox();
            this.lblCtrlCnlObj = new System.Windows.Forms.Label();
            this.lblCtrlCnlKP = new System.Windows.Forms.Label();
            this.txtCtrlCnlObjNum = new System.Windows.Forms.TextBox();
            this.txtCtrlCnlObjName = new System.Windows.Forms.TextBox();
            this.gbInCnl.SuspendLayout();
            this.gbCtrlCnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblInCnl
            // 
            this.lblInCnl.AutoSize = true;
            this.lblInCnl.Location = new System.Drawing.Point(10, 16);
            this.lblInCnl.Name = "lblInCnl";
            this.lblInCnl.Size = new System.Drawing.Size(38, 13);
            this.lblInCnl.TabIndex = 0;
            this.lblInCnl.Text = "Канал";
            // 
            // txtInCnlNum
            // 
            this.txtInCnlNum.Location = new System.Drawing.Point(13, 32);
            this.txtInCnlNum.Name = "txtInCnlNum";
            this.txtInCnlNum.ReadOnly = true;
            this.txtInCnlNum.Size = new System.Drawing.Size(50, 20);
            this.txtInCnlNum.TabIndex = 1;
            // 
            // txtInCnlName
            // 
            this.txtInCnlName.Location = new System.Drawing.Point(69, 32);
            this.txtInCnlName.Name = "txtInCnlName";
            this.txtInCnlName.ReadOnly = true;
            this.txtInCnlName.Size = new System.Drawing.Size(288, 20);
            this.txtInCnlName.TabIndex = 2;
            // 
            // txtCtrlCnlName
            // 
            this.txtCtrlCnlName.Location = new System.Drawing.Point(69, 32);
            this.txtCtrlCnlName.Name = "txtCtrlCnlName";
            this.txtCtrlCnlName.ReadOnly = true;
            this.txtCtrlCnlName.Size = new System.Drawing.Size(288, 20);
            this.txtCtrlCnlName.TabIndex = 2;
            // 
            // txtCtrlCnlNum
            // 
            this.txtCtrlCnlNum.Location = new System.Drawing.Point(13, 32);
            this.txtCtrlCnlNum.Name = "txtCtrlCnlNum";
            this.txtCtrlCnlNum.ReadOnly = true;
            this.txtCtrlCnlNum.Size = new System.Drawing.Size(50, 20);
            this.txtCtrlCnlNum.TabIndex = 1;
            // 
            // lblCtrlCnl
            // 
            this.lblCtrlCnl.AutoSize = true;
            this.lblCtrlCnl.Location = new System.Drawing.Point(10, 16);
            this.lblCtrlCnl.Name = "lblCtrlCnl";
            this.lblCtrlCnl.Size = new System.Drawing.Size(38, 13);
            this.lblCtrlCnl.TabIndex = 0;
            this.lblCtrlCnl.Text = "Канал";
            // 
            // txtInCnlObjName
            // 
            this.txtInCnlObjName.Location = new System.Drawing.Point(69, 71);
            this.txtInCnlObjName.Name = "txtInCnlObjName";
            this.txtInCnlObjName.ReadOnly = true;
            this.txtInCnlObjName.Size = new System.Drawing.Size(288, 20);
            this.txtInCnlObjName.TabIndex = 5;
            // 
            // txtInCnlObjNum
            // 
            this.txtInCnlObjNum.Location = new System.Drawing.Point(13, 71);
            this.txtInCnlObjNum.Name = "txtInCnlObjNum";
            this.txtInCnlObjNum.ReadOnly = true;
            this.txtInCnlObjNum.Size = new System.Drawing.Size(50, 20);
            this.txtInCnlObjNum.TabIndex = 4;
            // 
            // lblInCnlObj
            // 
            this.lblInCnlObj.AutoSize = true;
            this.lblInCnlObj.Location = new System.Drawing.Point(10, 55);
            this.lblInCnlObj.Name = "lblInCnlObj";
            this.lblInCnlObj.Size = new System.Drawing.Size(45, 13);
            this.lblInCnlObj.TabIndex = 3;
            this.lblInCnlObj.Text = "Объект";
            // 
            // txtInCnlKPName
            // 
            this.txtInCnlKPName.Location = new System.Drawing.Point(69, 110);
            this.txtInCnlKPName.Name = "txtInCnlKPName";
            this.txtInCnlKPName.ReadOnly = true;
            this.txtInCnlKPName.Size = new System.Drawing.Size(288, 20);
            this.txtInCnlKPName.TabIndex = 8;
            // 
            // txtInCnlKPNum
            // 
            this.txtInCnlKPNum.Location = new System.Drawing.Point(13, 110);
            this.txtInCnlKPNum.Name = "txtInCnlKPNum";
            this.txtInCnlKPNum.ReadOnly = true;
            this.txtInCnlKPNum.Size = new System.Drawing.Size(50, 20);
            this.txtInCnlKPNum.TabIndex = 7;
            // 
            // lblInCnlKP
            // 
            this.lblInCnlKP.AutoSize = true;
            this.lblInCnlKP.Location = new System.Drawing.Point(10, 94);
            this.lblInCnlKP.Name = "lblInCnlKP";
            this.lblInCnlKP.Size = new System.Drawing.Size(22, 13);
            this.lblInCnlKP.TabIndex = 6;
            this.lblInCnlKP.Text = "КП";
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(307, 310);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Закрыть";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // gbInCnl
            // 
            this.gbInCnl.Controls.Add(this.lblInCnl);
            this.gbInCnl.Controls.Add(this.txtInCnlNum);
            this.gbInCnl.Controls.Add(this.txtInCnlKPName);
            this.gbInCnl.Controls.Add(this.txtInCnlName);
            this.gbInCnl.Controls.Add(this.txtInCnlKPNum);
            this.gbInCnl.Controls.Add(this.lblInCnlObj);
            this.gbInCnl.Controls.Add(this.lblInCnlKP);
            this.gbInCnl.Controls.Add(this.txtInCnlObjNum);
            this.gbInCnl.Controls.Add(this.txtInCnlObjName);
            this.gbInCnl.Location = new System.Drawing.Point(12, 12);
            this.gbInCnl.Name = "gbInCnl";
            this.gbInCnl.Padding = new System.Windows.Forms.Padding(10, 3, 10, 10);
            this.gbInCnl.Size = new System.Drawing.Size(370, 143);
            this.gbInCnl.TabIndex = 0;
            this.gbInCnl.TabStop = false;
            this.gbInCnl.Text = "Входной канал";
            // 
            // gbCtrlCnl
            // 
            this.gbCtrlCnl.Controls.Add(this.txtCtrlCnlKPName);
            this.gbCtrlCnl.Controls.Add(this.txtCtrlCnlKPNum);
            this.gbCtrlCnl.Controls.Add(this.lblCtrlCnlObj);
            this.gbCtrlCnl.Controls.Add(this.lblCtrlCnlKP);
            this.gbCtrlCnl.Controls.Add(this.txtCtrlCnlObjNum);
            this.gbCtrlCnl.Controls.Add(this.txtCtrlCnlObjName);
            this.gbCtrlCnl.Controls.Add(this.lblCtrlCnl);
            this.gbCtrlCnl.Controls.Add(this.txtCtrlCnlNum);
            this.gbCtrlCnl.Controls.Add(this.txtCtrlCnlName);
            this.gbCtrlCnl.Location = new System.Drawing.Point(12, 161);
            this.gbCtrlCnl.Name = "gbCtrlCnl";
            this.gbCtrlCnl.Padding = new System.Windows.Forms.Padding(10, 3, 10, 10);
            this.gbCtrlCnl.Size = new System.Drawing.Size(370, 143);
            this.gbCtrlCnl.TabIndex = 1;
            this.gbCtrlCnl.TabStop = false;
            this.gbCtrlCnl.Text = "Канал управления";
            // 
            // txtCtrlCnlKPName
            // 
            this.txtCtrlCnlKPName.Location = new System.Drawing.Point(69, 110);
            this.txtCtrlCnlKPName.Name = "txtCtrlCnlKPName";
            this.txtCtrlCnlKPName.ReadOnly = true;
            this.txtCtrlCnlKPName.Size = new System.Drawing.Size(288, 20);
            this.txtCtrlCnlKPName.TabIndex = 8;
            // 
            // txtCtrlCnlKPNum
            // 
            this.txtCtrlCnlKPNum.Location = new System.Drawing.Point(13, 110);
            this.txtCtrlCnlKPNum.Name = "txtCtrlCnlKPNum";
            this.txtCtrlCnlKPNum.ReadOnly = true;
            this.txtCtrlCnlKPNum.Size = new System.Drawing.Size(50, 20);
            this.txtCtrlCnlKPNum.TabIndex = 7;
            // 
            // lblCtrlCnlObj
            // 
            this.lblCtrlCnlObj.AutoSize = true;
            this.lblCtrlCnlObj.Location = new System.Drawing.Point(10, 55);
            this.lblCtrlCnlObj.Name = "lblCtrlCnlObj";
            this.lblCtrlCnlObj.Size = new System.Drawing.Size(45, 13);
            this.lblCtrlCnlObj.TabIndex = 3;
            this.lblCtrlCnlObj.Text = "Объект";
            // 
            // lblCtrlCnlKP
            // 
            this.lblCtrlCnlKP.AutoSize = true;
            this.lblCtrlCnlKP.Location = new System.Drawing.Point(10, 94);
            this.lblCtrlCnlKP.Name = "lblCtrlCnlKP";
            this.lblCtrlCnlKP.Size = new System.Drawing.Size(22, 13);
            this.lblCtrlCnlKP.TabIndex = 6;
            this.lblCtrlCnlKP.Text = "КП";
            // 
            // txtCtrlCnlObjNum
            // 
            this.txtCtrlCnlObjNum.Location = new System.Drawing.Point(13, 71);
            this.txtCtrlCnlObjNum.Name = "txtCtrlCnlObjNum";
            this.txtCtrlCnlObjNum.ReadOnly = true;
            this.txtCtrlCnlObjNum.Size = new System.Drawing.Size(50, 20);
            this.txtCtrlCnlObjNum.TabIndex = 4;
            // 
            // txtCtrlCnlObjName
            // 
            this.txtCtrlCnlObjName.Location = new System.Drawing.Point(69, 71);
            this.txtCtrlCnlObjName.Name = "txtCtrlCnlObjName";
            this.txtCtrlCnlObjName.ReadOnly = true;
            this.txtCtrlCnlObjName.Size = new System.Drawing.Size(288, 20);
            this.txtCtrlCnlObjName.TabIndex = 5;
            // 
            // FrmItemInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(394, 345);
            this.Controls.Add(this.gbCtrlCnl);
            this.Controls.Add(this.gbInCnl);
            this.Controls.Add(this.btnClose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmItemInfo";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Информация об элементе";
            this.gbInCnl.ResumeLayout(false);
            this.gbInCnl.PerformLayout();
            this.gbCtrlCnl.ResumeLayout(false);
            this.gbCtrlCnl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblInCnl;
        private System.Windows.Forms.TextBox txtInCnlNum;
        private System.Windows.Forms.TextBox txtInCnlName;
        private System.Windows.Forms.TextBox txtCtrlCnlName;
        private System.Windows.Forms.TextBox txtCtrlCnlNum;
        private System.Windows.Forms.Label lblCtrlCnl;
        private System.Windows.Forms.TextBox txtInCnlObjName;
        private System.Windows.Forms.TextBox txtInCnlObjNum;
        private System.Windows.Forms.Label lblInCnlObj;
        private System.Windows.Forms.TextBox txtInCnlKPName;
        private System.Windows.Forms.TextBox txtInCnlKPNum;
        private System.Windows.Forms.Label lblInCnlKP;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox gbInCnl;
        private System.Windows.Forms.GroupBox gbCtrlCnl;
        private System.Windows.Forms.TextBox txtCtrlCnlKPName;
        private System.Windows.Forms.TextBox txtCtrlCnlKPNum;
        private System.Windows.Forms.Label lblCtrlCnlObj;
        private System.Windows.Forms.Label lblCtrlCnlKP;
        private System.Windows.Forms.TextBox txtCtrlCnlObjNum;
        private System.Windows.Forms.TextBox txtCtrlCnlObjName;
    }
}