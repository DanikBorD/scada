#!/bin/sh
sudo update-rc.d -f scadaserver remove
sudo update-rc.d -f scadacomm remove