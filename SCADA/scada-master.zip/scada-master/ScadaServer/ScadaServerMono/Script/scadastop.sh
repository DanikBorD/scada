#!/bin/sh
echo "Stop Rapid SCADA..."
sudo service scadacomm stop
sudo service scadaserver stop