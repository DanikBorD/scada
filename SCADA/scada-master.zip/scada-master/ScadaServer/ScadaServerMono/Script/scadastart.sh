#!/bin/sh
echo "Start Rapid SCADA..."
sudo service scadaserver start
sudo service scadacomm start