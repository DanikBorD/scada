﻿
namespace PHmiConfigurator.Modules.Collection
{
    public class CollectionService : ModuleService, ICollectionService
    {
    }
}
