﻿namespace PHmiConfigurator.Modules.Collection
{
    /// <summary>
    /// Interaction logic for AlarmCategories.xaml
    /// </summary>
    public partial class AlarmCategories
    {
        public AlarmCategories()
        {
            InitializeComponent();
        }
    }
}
