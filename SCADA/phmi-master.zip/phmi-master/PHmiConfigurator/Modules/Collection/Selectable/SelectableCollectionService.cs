﻿
namespace PHmiConfigurator.Modules.Collection.Selectable
{
    public class SelectableCollectionService : CollectionService, ISelectableCollectionService
    {
    }
}
