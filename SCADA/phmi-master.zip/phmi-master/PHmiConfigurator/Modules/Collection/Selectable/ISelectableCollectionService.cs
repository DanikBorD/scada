﻿
namespace PHmiConfigurator.Modules.Collection.Selectable
{
    public interface ISelectableCollectionService : ICollectionService
    {
    }
}
