﻿namespace PHmiConfigurator.Modules.Collection
{
    /// <summary>
    /// Interaction logic for Logs.xaml
    /// </summary>
    public partial class Logs
    {
        public Logs()
        {
            InitializeComponent();
        }
    }
}
