﻿
namespace PHmiConfigurator.Modules.Collection
{
    /// <summary>
    /// Interaction logic for IoDevices.xaml
    /// </summary>
    public partial class IoDevices
    {
        public IoDevices()
        {
            InitializeComponent();
        }
    }
}
