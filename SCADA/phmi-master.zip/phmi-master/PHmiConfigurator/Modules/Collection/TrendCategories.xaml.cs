﻿
namespace PHmiConfigurator.Modules.Collection
{
    /// <summary>
    /// Interaction logic for TrendCategories.xaml
    /// </summary>
    public partial class TrendCategories
    {
        public TrendCategories()
        {
            InitializeComponent();
        }
    }
}
