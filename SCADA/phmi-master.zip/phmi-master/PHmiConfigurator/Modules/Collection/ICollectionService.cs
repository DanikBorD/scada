﻿
namespace PHmiConfigurator.Modules.Collection
{
    public interface ICollectionService : IModuleService
    {
    }
}
