﻿
namespace PHmiConfigurator.Modules.Collection
{
    /// <summary>
    /// Interaction logic for Users.xaml
    /// </summary>
    public partial class Users
    {
        public Users()
        {
            InitializeComponent();
        }
    }
}
