﻿using PHmiTools.Utils;

namespace PHmiConfigurator
{
    public interface IMainWindowService
    {
        IDialogHelper DialogHelper { get; }
    }
}
