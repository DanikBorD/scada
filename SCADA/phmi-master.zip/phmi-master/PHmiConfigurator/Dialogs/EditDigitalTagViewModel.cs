﻿using PHmiModel;
using PHmiModel.Entities;

namespace PHmiConfigurator.Dialogs
{
    public class EditDigitalTagViewModel : EditDialogViewModel<DigTag.DigTagMetadata>
    {
    }
}
