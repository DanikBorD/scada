﻿using PHmiModel;
using PHmiModel.Entities;

namespace PHmiConfigurator.Dialogs
{
    public class EditLogViewModel : EditDialogViewModel<Log.LogMetadata>
    {
    }
}
