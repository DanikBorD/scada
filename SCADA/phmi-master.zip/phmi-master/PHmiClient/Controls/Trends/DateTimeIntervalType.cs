﻿namespace PHmiClient.Controls.Trends
{
    public enum DateTimeIntervalType
    {
        Milliseconds,
        Seconds,
        Minutes,
        Hours,
        Days,
        Months,
        Years
    }
}