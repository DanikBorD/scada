﻿
namespace PHmiClient.Utils
{
    public interface IEditorHelper
    {
        object Clone(object obj);
        void Update(object source, object target);
    }
}
