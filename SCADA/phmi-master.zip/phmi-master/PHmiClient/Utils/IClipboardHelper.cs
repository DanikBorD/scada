﻿
namespace PHmiClient.Utils
{
    public interface IClipboardHelper
    {
        string GetText();
        void SetText(string text);
    }
}
