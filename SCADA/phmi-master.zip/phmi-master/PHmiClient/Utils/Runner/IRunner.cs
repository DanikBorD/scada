﻿namespace PHmiClient.Utils.Runner
{
    public interface IRunner
    {
        void Start();
        void Stop();
    }
}
