﻿using System;

namespace PHmiClient.Wcf
{
    internal interface IServiceClient : IService, IDisposable
    {
    }
}
