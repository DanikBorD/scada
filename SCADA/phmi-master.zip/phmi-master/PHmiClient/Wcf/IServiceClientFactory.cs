﻿namespace PHmiClient.Wcf
{
    internal interface IServiceClientFactory
    {
        IServiceClient Create();
    }
}
