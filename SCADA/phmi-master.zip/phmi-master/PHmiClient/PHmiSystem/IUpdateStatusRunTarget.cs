﻿namespace PHmiClient.PHmiSystem
{
    internal interface IUpdateStatusRunTarget : IServiceRunTarget
    {
    }
}
