﻿using PHmiClient.Utils.Runner;

namespace PHmiClient.PHmiSystem
{
    internal interface IPHmiRunTarget : IRunTarget
    {
    }
}
