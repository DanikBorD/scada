using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PHmiUnitTests")]
[assembly: InternalsVisibleTo("PHmiIntegrationTests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]

[assembly: AssemblyProduct("PHmi")]
[assembly: AssemblyCopyright("Copyright © 2012 by Rustam Sekerbayev")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyCompany("phmi.mail@gmail.com")]
[assembly: AssemblyDescription(".NET SCADA system")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("2.0.8371.78")]
[assembly: AssemblyFileVersion("2.0.8371.78")]
