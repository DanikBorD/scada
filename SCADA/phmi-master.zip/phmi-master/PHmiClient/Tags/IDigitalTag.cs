﻿namespace PHmiClient.Tags
{
    public interface IDigitalTag : ITag<bool?>
    {
    }
}
