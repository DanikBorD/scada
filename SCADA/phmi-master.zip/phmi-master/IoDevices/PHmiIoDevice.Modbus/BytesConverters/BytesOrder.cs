﻿namespace PHmiIoDevice.Modbus.BytesConverters
{
    public enum BytesOrder
    {
        HL, LH
    }
}
