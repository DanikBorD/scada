﻿namespace PHmiIoDevice.Modbus.Configuration
{
    public class RtuConfig: ComConfig
    {
        public const string Name = "Rtu";
        
        public RtuConfig() : base(Name)
        {
        }
    }
}
