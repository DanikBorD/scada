﻿namespace PHmiIoDevice.Modbus.Configuration
{
    public class AsciiViaTcpConfig : EnetConfig
    {
        public const string Name = "AsciiViaTcp";

        public AsciiViaTcpConfig() : base(Name)
        {
        }
    }
}
