﻿namespace PHmiIoDevice.Modbus.Configuration
{
    public class AsciiConfig: ComConfig
    {
        public const string Name = "Ascii";

        public AsciiConfig() : base(Name)
        {
        }
    }
}
