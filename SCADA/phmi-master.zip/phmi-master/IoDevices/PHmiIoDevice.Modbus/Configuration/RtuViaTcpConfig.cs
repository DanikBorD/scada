﻿namespace PHmiIoDevice.Modbus.Configuration
{
    public class RTUviaTCPConfig: EnetConfig
    {
        public const string Name = "RtuViaTcp";

        public RTUviaTCPConfig() : base(Name)
        {
        }
    }
}
