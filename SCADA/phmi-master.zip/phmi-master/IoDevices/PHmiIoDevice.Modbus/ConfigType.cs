﻿namespace PHmiIoDevice.Modbus
{
    public enum ConfigType
    {
        Tcp, Rtu, RtuViaTcp, Ascii, AsciiViaTcp
    }
}
