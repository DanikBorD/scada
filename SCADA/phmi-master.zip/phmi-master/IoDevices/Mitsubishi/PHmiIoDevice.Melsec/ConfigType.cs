﻿namespace PHmiIoDevice.Melsec
{
    public enum ConfigType
    {
        FxCom, FxEnet, Q
    }
}
