﻿using PHmiIoDeviceTools;

namespace PHmiIoDevice.Melsec.WriteInfos
{
    internal struct BitWriteInfo
    {
        public int Address;
        public WriteParameter WriteParameter;
        public int Index;
    }
}
