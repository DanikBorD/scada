﻿using PHmiClient.Utils.Runner;

namespace PHmiRunner.Utils
{
    public interface IProjectRunner : IRunner, IProject
    {
    }
}
