﻿namespace PHmiRunner.Utils.Trends
{
    public interface ITrendsRepositoryFactory
    {
        ITrendsRepository Create();
    }
}
