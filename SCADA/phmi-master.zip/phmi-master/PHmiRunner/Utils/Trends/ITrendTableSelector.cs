﻿namespace PHmiRunner.Utils.Trends
{
    public interface ITrendTableSelector
    {
        int NextTable();
    }
}
