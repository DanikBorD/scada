﻿namespace PHmiRunner.Utils
{
    public interface IDataDbCreator
    {
        bool Start();
    }
}
