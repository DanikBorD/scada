﻿
namespace PHmiModel.Interfaces
{
    public interface INamedEntity : IEntity
    {
        string Name { get; set; }
    }
}
